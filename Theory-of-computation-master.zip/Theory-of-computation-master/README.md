# Theory-of-computation
course project
This is an project by using Python parsing JSON to analyze data;
And then final Using PIG based on Hadoop to analyze big data;
it a simple model;
